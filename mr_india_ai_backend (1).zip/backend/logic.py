import base64
import random

def generate_reply(message):
    return f"You said: {message}. Here's my response!"

def synthesize_voice(text, gender):
    # Placeholder: In production, replace this with real TTS
    dummy_audio = b"FakeAudioData"
    return base64.b64encode(dummy_audio).decode("utf-8")