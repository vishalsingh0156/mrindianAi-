from fastapi import FastAPI, Request
from fastapi.middleware.cors import CORSMiddleware
from pydantic import BaseModel
from backend.logic import generate_reply, synthesize_voice

app = FastAPI()

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

class ChatInput(BaseModel):
    message: str
    gender: str

@app.post("/chat")
async def chat(input: ChatInput):
    reply = generate_reply(input.message)
    voice = synthesize_voice(reply, input.gender)
    return {"reply": reply, "voice": voice}